from django.db import models

# Create your models here.

class movie(models.Model):
	sno = models.IntegerField(default=0)
	Title = models.CharField(max_length=999)
	Rating = models.FloatField()
	TotalVotes = models.CharField(max_length=99999)
	Genre1 = models.CharField(max_length=999)
	Genre2 = models.CharField(max_length=999)
	Genre3 = models.CharField(max_length=999)
	MetaCritic = models.IntegerField()
	Budget = models.CharField(max_length=9999)
	Runtime = models.CharField(max_length=9999)