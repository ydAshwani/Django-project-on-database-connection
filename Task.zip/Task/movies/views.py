from django.shortcuts import render
import csv,os
from movies.models import movie
from django.shortcuts import redirect
from django import forms
#from fusioncharts import FusionCharts

def home(request):
	#Upload CSV details to DB

	movie.objects.all().delete()

	with open(os.path.dirname(os.path.realpath(__file__))+"/IMDB - MovieData.csv") as csvfile:
		reader = csv.DictReader(csvfile)
		for row in reader:
			d = movie(sno=row[''],Title=row['Title'],Rating=row['Rating'],TotalVotes=row['TotalVotes'],Genre1=row['Genre1'],Genre2=row['Genre2'],Genre3=row['Genre3'],MetaCritic=row['MetaCritic'],Budget=row['Budget'],Runtime=row['Runtime'])
			d.save()
	return redirect("/list")


def list(request):
	all_obj = movie.objects.all()
	return render(request,'movies/list.html',{'all_obj':all_obj})

def yourSort(request):
	#all_obj = movie.objects.order_by('Rating')
	col = request.GET['column'];
	if (col=='rating'):
		all_obj = movie.objects.order_by('Rating')
	if (col=='totalvote'):
		all_obj = movie.objects.order_by('TotalVotes')
	if (col=='metacritic'):
		all_obj = movie.objects.order_by('MetaCritic')
	if (col=='budget'):
		all_obj = movie.objects.order_by('Budget')
	if (col=='runtime'):
		all_obj = movie.objects.order_by('Runtime')

	return render(request,'movies/list.html',{'all_obj':all_obj})

def best(request):
	all_obj=[]
	x=movie.objects.order_by('Rating')[len(movie.objects.order_by('Rating'))-1].Rating
	p=movie.objects.all()
	for i in p:
		if(i.Rating==x):
		  all_obj.append(i)
	return render(request,'movies/list.html',{'all_obj':all_obj})

def worst(request):
	all_obj=[]
	x=movie.objects.order_by('Rating')[0].Rating
	p=movie.objects.all()
	for i in p:
		if(i.Rating==x):
		  all_obj.append(i)
	return render(request,'movies/list.html',{'all_obj':all_obj})

def average(request):
	all_obj=[]
	x=movie.objects.order_by('Rating')[int(len(movie.objects.order_by('Rating'))/2)-1].Rating
	p=movie.objects.all()
	for i in p:
		if(i.Rating==x):
		  all_obj.append(i)
	return render(request,'movies/list.html',{'all_obj':all_obj})

"""def bar(request):
	dataSource = {}
	dataSource['chart'] = {"caption": "Movies Data","subCaption": "Movie bar graph from highest rating to lowest rating","xAxisName": "Movie Name","yAxisName": "Rating","theme": "zune"}
	dataSource['data'] = []
	for key in movie.objects.all():
	      data = {}
	      data['label'] = key.Title
	      data['value'] = key.Rating
	      dataSource['data'].append(data)
	column2D = FusionCharts("column2D", "ex1" , "600", "350", "chart-1", "json", dataSource)
	return render(request, 'graph.html', {'output': column2D.render()})"""

def bar(request):
	all_obj = reversed(movie.objects.order_by('Rating'));
	return render(request,'movies/graph.html',{'all_obj':all_obj})
