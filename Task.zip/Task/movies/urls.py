from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home),
    path('list',views.list),
    path('sort', views.yourSort),
    path('best',views.best),
    path('average',views.average),
    path('worst',views.worst),
    path('bar',views.bar)
]
